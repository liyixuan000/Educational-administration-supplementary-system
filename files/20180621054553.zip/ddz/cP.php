<?php
include "./dbconnect.php";
$query = mysql_query("select * from `tables` where `ID` = '".$_GET[tableID]."'");
$num = mysql_num_rows($query);
if($num && mysql_result($query, 0, "lord") != ""){
	$player1_name = mysql_result($query, 0, "player1_name");
	$player2_name = mysql_result($query, 0, "player2_name");
	$player3_name = mysql_result($query, 0, "player3_name");
	$player1_p = mysql_result($query, 0, "player1_p");
	$player2_p = mysql_result($query, 0, "player2_p");
	$player3_p = mysql_result($query, 0, "player3_p");
	$lord_p = mysql_result($query, 0, "lord_p");
	$beishu = mysql_result($query, 0, "beishu");
	$flag = mysql_result($query, 0, "flag");
	if($_GET[type] == "zhadan")
	$beishu *= 2;
	if($username == $player1_name && $flag == $username)
	{
		$player1_p = resetP($_GET[cToShow], $player1_p);
		mysql_query("update `tables` set `beishu` = '$beishu',`flag` = '".($player1_p?$player2_name:'')."',`player1_p` = '$player1_p',`player1_show` = '".$_GET[cToShow]."',`player2_show` = ''".($player1_p?"":",`player1_status` = '',`player2_status` = '',`player3_status` = ''")." where `ID` = '".$_GET[tableID]."'");
	}
	if($username == $player2_name && $flag == $username){
		$player2_p = resetP($_GET[cToShow], $player2_p);
		mysql_query("update `tables` set `beishu` = '$beishu',`flag` = '".($player2_p?$player3_name:'')."',`player2_p` = '$player2_p',`player2_show` = '".$_GET[cToShow]."',`player3_show` = ''".($player2_p?"":",`player1_status` = '',`player2_status` = '',`player3_status` = ''")." where `ID` = '".$_GET[tableID]."'");
	}
	if($username == $player3_name && $flag == $username){
		$player3_p = resetP($_GET[cToShow], $player3_p);
		mysql_query("update `tables` set `beishu` = '$beishu',`flag` = '".($player3_p?$player1_name:'')."',`player3_p` = '$player3_p',`player3_show` = '".$_GET[cToShow]."',`player1_show` = ''".($player3_p?"":",`player1_status` = '',`player2_status` = '',`player3_status` = ''")." where `ID` = '".$_GET[tableID]."'");
	}
}
function resetP($c,$p){
		$exG = explode("|", $c);
		$ex = explode("|", $p);
		for($p = "", $i = 0;$i < sizeof($ex) - 1;$i ++)
		{
			$f = 0;
			for($j = 0;$j < sizeof($exG) - 1;$j ++)
			{
				if($exG[$j] == $ex[$i])
				{
					$f = 1;
					break;
				}
			}
			if($f == 0)
			$p .= $ex[$i]."|";
		}
	return $p;
}
?>