<?php
include "./dbconnect.php";
$query = mysql_query("select * from `tables` where `ID` = '".$_GET[tableID]."'");
$num = mysql_num_rows($query);
if($num){
	$player1_name = mysql_result($query, 0, "player1_name");
	$player2_name = mysql_result($query, 0, "player2_name");
	$player3_name = mysql_result($query, 0, "player3_name");
	if($username == $player1_name)
	mysql_query("update `tables` set `player1_chat` = '".$_GET[content]."' where `ID` = '".$_GET[tableID]."'");
	if($username == $player2_name)
	mysql_query("update `tables` set `player2_chat` = '".$_GET[content]."' where `ID` = '".$_GET[tableID]."'");
	if($username == $player3_name)
	mysql_query("update `tables` set `player3_chat` = '".$_GET[content]."' where `ID` = '".$_GET[tableID]."'");
}
?>