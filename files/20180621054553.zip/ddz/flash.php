<?php
include "./dbconnect.php";
if($_COOKIE[username] == '')
{
	header("location:guestAddIn.php");
	exit;
}
?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh_cn" lang="zh_cn">
<head>
<script language="JavaScript">
	var soundCount = 0;
    function mkSound(url)
    {
		if(soundCount > 5)
			soundCount = 0;
		document.getElementById('sound'+soundCount).src = url;
		soundCount ++;
    }
	function inviteToGame(){
		if(window.clipboardData.setData('text',document.location.href))
			alert('���Ƴɹ���Ctrl + v ����ַ���͸����Ѽ��ɣ�');
	}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>��ҳ������</title>
<script language="javascript">AC_FL_RunContent = 0;</script>
<script src="AC_RunActiveContent.js" language="javascript"></script>
</head>
<body bgcolor="#51719d" style="text-align:center; margin:0px;">
<bgsound id="sound0" loop="1">
<bgsound id="sound1" loop="1">
<bgsound id="sound2" loop="1">
<bgsound id="sound3" loop="1">
<bgsound id="sound4" loop="1">
<bgsound id="sound5" loop="1">
<!--ӰƬ��ʹ�õ� URL-->
<!--ӰƬ��ʹ�õ��ı�-->
<!--
<p align="right"></p>
<p align="center"></p>
<p align="center"></p>
<p align="center"></p>
<p align="center"></p>
<p align="center"></p>
<p align="center"></p>
<p align="center"></p>
<p align="center"></p>
<p align="center"></p>
<p align="center"></p>
<p align="left"></p>
-->
<!-- saved from url=(0013)about:internet -->
<script language="javascript">
	if (AC_FL_RunContent == 0) {
		alert("��ҳ��Ҫ AC_RunActiveContent.js");
	} else {
		AC_FL_RunContent(
			'codebase', 'http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0',
			'width', '800',
			'height', '650',
			'src', 'flash',
			'quality', 'high',
			'pluginspage', 'http://www.macromedia.com/go/getflashplayer',
			'align', 'middle',
			'play', 'true',
			'loop', 'true',
			'scale', 'showall',
			'wmode', 'window',
			'devicefont', 'false',
			'id', 'flash',
			'bgcolor', '#51719d',
			'name', 'flash',
			'menu', 'true',
			'allowFullScreen', 'false',
			'allowScriptAccess','sameDomain',
			'movie', 'flash',
			'salign', ''
			); //end AC code
	}
</script>
<noscript>
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0" width="800" height="650" id="flash" align="middle">
	<param name="allowScriptAccess" value="sameDomain" />
	<param name="allowFullScreen" value="false" />
	<param name="movie" value="flash.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#51719d" />	<embed src="flash.swf" quality="high" bgcolor="#51719d" width="800" height="650" name="flash" align="middle" allowScriptAccess="sameDomain" allowFullScreen="false" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
	</object>
</noscript>
</body>
</html>
<span style="display:none">
<script type="text/javascript" src="http://js.tongji.cn.yahoo.com/313377/ystat.js"></script><noscript><a href="http://tongji.cn.yahoo.com"><img src="http://img.tongji.cn.yahoo.com/313377/ystat.gif"/></a></noscript>
</span>
