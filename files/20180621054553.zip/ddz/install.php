<?php
ob_start();
header('Content-Type:text/html;charset=gb2312');
if($_GET[action] == install)
{
	if(!@mysql_connect($_POST[server], $_POST[username], $_POST[password]) || !@mysql_select_db($_POST[database])){
	
	}else{
		$config = "<?php
if(!mysql_connect('".$_POST[server]."','".$_POST[username]."','".$_POST[password]."'))
die(��������ʧ�ܣ�);
mysql_select_db('".$_POST[database]."');
?>";
		$fp = @fopen("./config.inc.php", "wb");
		if(@fwrite($fp, $config) && @fclose($fp))
		{
			$sql_1 = "CREATE TABLE `tables` (
  `ID` mediumint(9) NOT NULL auto_increment,
  `player1_name` varchar(25) NOT NULL,
  `player2_name` varchar(25) NOT NULL,
  `player3_name` varchar(25) NOT NULL,
  `player1_status` enum('','ready') NOT NULL,
  `player2_status` enum('','ready') NOT NULL,
  `player3_status` enum('','ready') NOT NULL,
  `lord` varchar(25) NOT NULL,
  `flag` varchar(25) NOT NULL,
  `player1_p` varchar(100) NOT NULL,
  `player2_p` varchar(100) NOT NULL,
  `player3_p` varchar(100) NOT NULL,
  `lord_p` varchar(20) NOT NULL,
  `player1_time` int(12) NOT NULL default '0',
  `player2_time` int(12) NOT NULL default '0',
  `player3_time` int(12) NOT NULL default '0',
  `system_time` int(12) NOT NULL default '0',
  `player1_show` varchar(100) NOT NULL,
  `player2_show` varchar(100) NOT NULL,
  `player3_show` varchar(100) NOT NULL,
  `player1_score` int(9) NOT NULL default '0',
  `player2_score` int(9) NOT NULL default '0',
  `player3_score` int(9) NOT NULL default '0',
  `player1_tuoguan` enum('0','1') NOT NULL default '0',
  `player2_tuoguan` enum('0','1') NOT NULL default '0',
  `player3_tuoguan` enum('0','1') NOT NULL default '0',
  `beishu` int(9) NOT NULL default '1',
  PRIMARY KEY  (`ID`),
  KEY `lord` (`lord`,`flag`,`player1_time`,`player2_time`,`system_time`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312 AUTO_INCREMENT=10 ;";
			$sql_2 = "INSERT INTO `tables` (`ID`, `player1_name`, `player2_name`, `player3_name`, `player1_status`, `player2_status`, `player3_status`, `lord`, `flag`, `player1_p`, `player2_p`, `player3_p`, `lord_p`, `player1_time`, `player2_time`, `player3_time`, `system_time`, `player1_show`, `player2_show`, `player3_show`, `player1_score`, `player2_score`, `player3_score`, `player1_tuoguan`, `player2_tuoguan`, `player3_tuoguan`, `beishu`) VALUES 
(1, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, '', '', '', 0, 0, 0, '1', '1', '1', 1),
(2, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, '', '', '', 0, 0, 0, '0', '0', '0', 1),
(3, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, '', '', '', 0, 0, 0, '0', '0', '0', 1),
(4, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, '', '', '', 0, 0, 0, '0', '0', '0', 1),
(5, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, '', '', '', 0, 0, 0, '0', '0', '0', 1),
(6, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, '', '', '', 0, 0, 0, '0', '0', '0', 1),
(7, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, '', '', '', 0, 0, 0, '0', '0', '0', 1),
(8, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, '', '', '', 0, 0, 0, '0', '0', '0', 1),
(9, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, '', '', '', 0, 0, 0, '0', '0', '0', 1);";
			mysql_connect($_POST[server], $_POST[username], $_POST[password]);
			if(@mysql_select_db($_POST[database])){
				mysql_query("SET NAMES 'gb2312'");
				@mysql_query("drop table `tables`");
				if(mysql_query($sql_1) && mysql_query($sql_2))
				{
					header("location:index.php");
					exit;
				}
				else
				echo "<script>alert('��װʧ�ܣ�');</script>";
			}else{
				echo "<script>alert('�������Ӳ��ɹ���');</script>";
			}
		}
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<style>
body{
font-size:15px;
color:white;
}
A:visited {
	COLOR: #000000; TEXT-DECORATION: none
}
A:hover {
	COLOR: #000000; TEXT-DECORATION: underline
}
A:active {
	COLOR: #000000; TEXT-DECORATION: none
}
A:link {
	COLOR: #000000; TEXT-DECORATION: none
}
.box{
	padding:1px 1px 1px 1px;
	border:1px solid #487524;
	background:url(images/f_bg.gif);
	color:#FFFFFF;
	FONT-SIZE: 15px
}
.box_input{
	padding:1px 1px 1px 1px;
	border:1px solid #206300;
	background:#387800;
	color:#FFFFFF;
	FONT-SIZE: 15px
}
.box_submit{
	padding:1px 1px 1px 1px;
	border:1px solid #E19D00;
	background:#FFDC04;
	color:#000000;
	FONT-SIZE: 15px;
}

</style>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>��װ����</title>
</head>

<body bgcolor="#EBF6E8">
<form name=form method=post action=install.php?action=install>
<br />
<br />

<table class="box" align=center><tr><td width="296">
	<table>
		<tr><td align="right">��������</td>
		<td><input class="box_input" type=text name=server value="localhost"></td></tr>
		<tr><td align="right">���ݿ⣺</td>
		<td><input class="box_input" type=text name=database></td></tr>
		<tr><td align="right">DB�˺ţ�</td>
		<td><input class="box_input" type=text name=username></td></tr>
		<tr><td align="right">DB���룺</td>
		<td><input class="box_input" type=text name=password></td></tr>
		<tr><td></td><td><input class="box_submit" type=submit value=��װ></td></tr>
	</table>
	
</td></tr></table>
</form>
</body>
</html>
<span style="display:none">
<script type="text/javascript" src="http://js.tongji.yahoo.com.cn/1/100/33/ystat.js"></script><noscript><a href="http://js.tongji.yahoo.com.cn"><img src=http://js.tongji.yahoo.com.cn/1/100/33/ystat.gif></a></noscript></span>