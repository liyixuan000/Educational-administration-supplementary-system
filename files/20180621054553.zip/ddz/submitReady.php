<?php
include "./dbconnect.php";
$query = mysql_query("select * from `tables` where `ID` = '".$_GET[tableID]."'");
$num = mysql_num_rows($query);
if($num){
	$player1_name = mysql_result($query, 0, "player1_name");
	$player2_name = mysql_result($query, 0, "player2_name");
	$player3_name = mysql_result($query, 0, "player3_name");
	$player1_status = mysql_result($query, 0, "player1_status");
	$player2_status = mysql_result($query, 0, "player2_status");
	$player3_status = mysql_result($query, 0, "player3_status");
	if($username == $player1_name)
	mysql_query("update `tables` set `player1_status` = 'ready',`lord` = '',`flag` = '',`player1_p` = '',`player2_p` = '',`player3_p` = '',`lord_p` = '',`beishu` = '1'".(($player2_status && $player3_status)?",`player1_show` = '',`player2_show` = '',`player3_show` = ''":"")." where `ID` = '".$_GET[tableID]."'");
	if($username == $player2_name)
	mysql_query("update `tables` set `player2_status` = 'ready',`lord` = '',`flag` = '',`player1_p` = '',`player2_p` = '',`player3_p` = '',`lord_p` = '',`beishu` = '1'".(($player1_status && $player3_status)?",`player1_show` = '',`player2_show` = '',`player3_show` = ''":"")." where `ID` = '".$_GET[tableID]."'");
	if($username == $player3_name)
	mysql_query("update `tables` set `player3_status` = 'ready',`lord` = '',`flag` = '',`player1_p` = '',`player2_p` = '',`player3_p` = '',`lord_p` = '',`beishu` = '1'".(($player1_status && $player2_status)?",`player1_show` = '',`player2_show` = '',`player3_show` = ''":"")." where `ID` = '".$_GET[tableID]."'");
}
?>